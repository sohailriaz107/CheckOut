
<?php $__env->startSection('css'); ?>
    <style>
        .help-block {
            color: red;
        }

    </style>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <!-- Form Start -->
    <div class="container-fluid pt-4 px-4">
        <div class="row g-4">
            <div class="col-sm-12 col-md-12">
                <div class="bg-light rounded h-100 p-4">

                    <h4 class="mb-4">Settings</h4>
                    <nav>
                        <div class="nav nav-tabs" id="nav-tab" role="tablist">
                            <button class="nav-link active" id="nav-paypal-tab" data-bs-toggle="tab"
                                data-bs-target="#nav-paypal" type="button" role="tab" aria-controls="nav-paypal"
                                aria-selected="true">Paypal</button>
                            <button class="nav-link" id="nav-credit_card-tab" data-bs-toggle="tab"
                                data-bs-target="#nav-credit_card" type="button" role="tab" aria-controls="nav-credit_card"
                                aria-selected="false">Credit Card</button>

                        </div>
                    </nav>
                    <div class="tab-content pt-3" id="nav-tabContent">
                        <div class="tab-pane fade show active" id="nav-paypal" role="tabpanel"
                            aria-labelledby="nav-paypal-tab">
                            <form action="<?php echo e(route('admin.merchants.add')); ?>" method="POST" enctype="multipart/form-data">
                                <?php echo e(csrf_field()); ?>

                                <h6>Sandbox Credentials</h6>
                                <br>
                                <div class="row mb-3">
                                    <label for="name" class="col-sm-4 col-form-label">Name</label>
                                    <div class="col-sm-5">
                                        <input type="text" class="form-control" id="name" name="name"
                                            value="<?php echo e(old('name')); ?>">
                                        <?php if($errors->has('name')): ?>
                                            <span class="help-block"><?php echo $errors->first('name'); ?></span>
                                        <?php endif; ?>
                                    </div>
                                </div>
                                <div class="row mb-3">
                                    <label for="email" class="col-sm-4 col-form-label">Email</label>
                                    <div class="col-sm-5">
                                        <input type="email" class="form-control" id="email" name="email"
                                            value="<?php echo e(old('email')); ?>">
                                        <?php if($errors->has('email')): ?>
                                            <span class="help-block"><?php echo $errors->first('email'); ?></span>
                                        <?php endif; ?>
                                    </div>
                                </div>
                                <br>
                                <h6>Live Credentials</h6>
                                <br>
                                <div class="row mb-3">
                                    <label for="name" class="col-sm-4 col-form-label">Name</label>
                                    <div class="col-sm-5">
                                        <input type="text" class="form-control" id="name" name="name"
                                            value="<?php echo e(old('name')); ?>">
                                        <?php if($errors->has('name')): ?>
                                            <span class="help-block"><?php echo $errors->first('name'); ?></span>
                                        <?php endif; ?>
                                    </div>
                                </div>
                                <div class="row mb-3">
                                    <label for="email" class="col-sm-4 col-form-label">Email</label>
                                    <div class="col-sm-5">
                                        <input type="email" class="form-control" id="email" name="email"
                                            value="<?php echo e(old('email')); ?>">
                                        <?php if($errors->has('email')): ?>
                                            <span class="help-block"><?php echo $errors->first('email'); ?></span>
                                        <?php endif; ?>
                                    </div>
                                </div>
                             
                                <div class="row mb-3">
                                    <label class="col-sm-4 col-form-label"></label>
                                    <button type="submit" class="btn  col-sm-5 btn-primary">Update</button>
                                </div>
                            </form>
                        </div>
                        <div class="tab-pane fade" id="nav-credit_card" role="tabpanel"
                            aria-labelledby="nav-credit_card-tab">
                            <form action="<?php echo e(route('admin.merchants.add')); ?>" method="POST" enctype="multipart/form-data">
                                <?php echo e(csrf_field()); ?>

                                <div class="row mb-3">
                                    <label for="name" class="col-sm-4 col-form-label">Name</label>
                                    <div class="col-sm-5">
                                        <input type="text" class="form-control" id="name" name="name"
                                            value="<?php echo e(old('name')); ?>">
                                        <?php if($errors->has('name')): ?>
                                            <span class="help-block"><?php echo $errors->first('name'); ?></span>
                                        <?php endif; ?>
                                    </div>
                                </div>
                                <div class="row mb-3">
                                    <label for="email" class="col-sm-4 col-form-label">Email</label>
                                    <div class="col-sm-5">
                                        <input type="email" class="form-control" id="email" name="email"
                                            value="<?php echo e(old('email')); ?>">
                                        <?php if($errors->has('email')): ?>
                                            <span class="help-block"><?php echo $errors->first('email'); ?></span>
                                        <?php endif; ?>
                                    </div>
                                </div>
                                <div class="row mb-3">
                                    <label for="telephone" class="col-sm-4 col-form-label">Telephone</label>
                                    <div class="col-sm-5">
                                        <input type="text" class="form-control" id="telephone" name="telephone"
                                            value="<?php echo e(old('telephone')); ?>">
                                        <?php if($errors->has('telephone')): ?>
                                            <span class="help-block"><?php echo $errors->first('telephone'); ?></span>
                                        <?php endif; ?>
                                    </div>
                                </div>
                                <div class="row mb-3">
                                    <label for="address" class="col-sm-4 col-form-label">Address</label>
                                    <div class="col-sm-5">
                                        <input type="text" class="form-control" id="address" name="address"
                                            value="<?php echo e(old('address')); ?>">
                                        <?php if($errors->has('address')): ?>
                                            <span class="help-block"><?php echo $errors->first('address'); ?></span>
                                        <?php endif; ?>
                                    </div>
                                </div>
                                <div class="row mb-3">
                                    <label for="merchant_code" class="col-sm-4 col-form-label">Merchant Code</label>
                                    <div class="col-sm-5">
                                        <input type="text" class="form-control" id="merchant_code" name="merchant_code"
                                            value="<?php echo e(old('merchant_code')); ?>">

                                    </div>
                                </div>
                                <div class="row mb-3">
                                    <label for="sercret_id" class="col-sm-4 col-form-label">Secret Id</label>
                                    <div class="col-sm-5">
                                        <input type="text" class="form-control" id="secret_id" name="secret_id"
                                            value="<?php echo e(old('secret_id')); ?>">

                                    </div>
                                </div>
                                <div class="row mb-3">
                                    <label for="store_name" class="col-sm-4 col-form-label">Store Name</label>
                                    <div class="col-sm-5">
                                        <input type="text" class="form-control" id="store_name" name="store_name"
                                            value="<?php echo e(old('store_name')); ?>">
                                    </div>
                                </div>
                                <div class="row mb-3">
                                    <label for="logo" class="col-sm-4 col-form-label">LOGO</label>
                                    <div class="col-sm-5">
                                        <img src="" id="imgPreview" alt="No Featured Image Added">
                                        <input onchange="readURL(this)" id="uploadFile" accept="image/*" name="logo"
                                            type="file">
                                    </div>
                                </div>
                                <div class="row mb-3">
                                    <label class="col-sm-4 col-form-label"></label>
                                    <button type="submit" class="btn  col-sm-5 btn-primary">Add</button>
                                </div>


                            </form>
                        </div>
                    </div>
                </div>

            </div>
        </div>

    </div>
    </div>
    <!-- Form End -->
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp74\htdocs\paymentportal\resources\views/admin/settings/index.blade.php ENDPATH**/ ?>