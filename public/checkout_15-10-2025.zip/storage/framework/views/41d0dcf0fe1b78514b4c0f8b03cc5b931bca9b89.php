<?php $__env->startSection('content'); ?>
    <!-- Form Start -->
    <div class="container-fluid pt-4 px-4">
        <div class="row g-4">
            <div class="col-sm-12 col-md-12">
                <div class="bg-light rounded h-100 p-4">
                    <div class="pull-right" style="float: right;">
                        <a href="<?php echo e(route('admin.merchants.edit',  ['merchant' => $merchant])); ?>">
                            <button type="button" class="btn btn-success">Edit</button>
                        </a>
                        <a href="<?php echo e(route('admin.merchants.index')); ?>">
                            <button type="button" class="btn btn-primary">Back</button>
                        </a>
                    </div>
                    <table class="table ">
                        <tr>
                            <td><b>Name</b></td>
                            <td><?php echo e($merchant->name); ?></td>
                        </tr>
                        <tr>
                            <td><b>Email</b></td>
                            <td><?php echo e($merchant->email); ?></td>
                        </tr>
                        <tr>
                            <td><b>Telephone</b></td>
                            <td><?php echo e($merchant->telephone); ?></td>
                        </tr>
                        <tr>
                            <td><b>Address</b></td>
                            <td><?php echo e($merchant->address); ?></td>
                        </tr>
                        <tr>
                            <td><b>URL</b></td>
                            <td><?php echo e($merchant->merchantUrl); ?></td>
                        </tr>
                        <tr>
                            <td><b>Merchant Code</b></td>
                            <td><?php echo e($merchant->merchant_code); ?></td>
                        </tr>
                        <tr>
                            <td><b>Secret ID</b></td>
                            <td><?php echo e($merchant->secret_id); ?></td>
                        </tr>
                        <tr>
                            <td><b>Store Name</b></td>
                            <td><?php echo e($merchant->store_name); ?></td>
                        </tr>
                    </table>
                </div>
            </div>

        </div>
    </div>
    <!-- Form End -->
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/vhosts/backpocket.ca/checkout.backpocket.ca/resources/views/admin/merchants/show.blade.php ENDPATH**/ ?>