     <!-- Sidebar Start -->
     <div class="sidebar pe-4 pb-3">
        <nav class="navbar bg-light navbar-light">
            <a href="#" class="navbar-brand mx-4 mb-3">
                <h3 class="text-primary">Payment <br> GateWay</h3>
            </a>

            <div class="navbar-nav w-100">
                <?php if(Auth::check() && Auth::user()->type != 'Merchant'): ?>
                <a href="<?php echo e(route('admin.dashboard')); ?>" class="nav-item nav-link <?php echo e((request()->is('admin/admin-dashboard')) ? 'active' : ''); ?>"><i class="fa fa-tachometer-alt me-2"></i>Dashboard</a>
                <?php endif; ?>
                <a href="<?php echo e(route('admin.transactions.index')); ?>" class="nav-item nav-link <?php echo e((request()->is('admin/Transactions')) ? 'active' : ''); ?>"><i class="fa fa-tachometer-alt me-2"></i>Transactions</a>
                <?php if(Auth::check() && Auth::user()->type != 'Merchant'): ?>
                <a href="<?php echo e(route('admin.merchants.index')); ?>" class="nav-item nav-link <?php echo e((request()->is('admin/merchants*')) ? 'active' : ''); ?>"><i class="fa fa-tachometer-alt me-2"></i>Merchants</a>
                <?php if(Auth::check() && Auth::user()->type == 'Admin'): ?>
                <a href="<?php echo e(route('admin.settings.index')); ?>" class="nav-item nav-link <?php echo e((request()->is('admin/settings')) ? 'active' : ''); ?>"><i class="fa fa-tachometer-alt me-2"></i>Settings</a>
                <a class="nav-item nav-link <?php echo e((request()->is('admin/users')) ? 'active' : ''); ?>" href="<?php echo e(route('users.index')); ?>"><i class="fa fa-tachometer-alt me-2"></i>Manage Users</a>
                <a class="nav-item nav-link <?php echo e((request()->is('admin/roles')) ? 'active' : ''); ?>" href="<?php echo e(route('roles.index')); ?>"><i class="fa fa-tachometer-alt me-2"></i>Manage Role</a>
                <?php endif; ?>
                <?php endif; ?>

            </div>
        </nav>
    </div>
    <!-- Sidebar End -->
<?php /**PATH /var/www/vhosts/backpocket.ca/checkout.backpocket.ca/resources/views/admin/layouts/nav.blade.php ENDPATH**/ ?>