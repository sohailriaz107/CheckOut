<?php $__env->startSection('css'); ?>
    <style>
           .help-block {
            color: red;
        }
    </style>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <!-- Form Start -->
    <div class="container-fluid pt-4 px-4">
        <div class="row g-4">
            <div class="col-sm-12 col-md-12">
                <div class="bg-light rounded h-100 p-4">
                    <div class="pull-right" style="float: right;">
                        <a href="<?php echo e(route('admin.merchants.index')); ?>"><button type="button" class="btn btn-primary">Back</button></a>
                    </div>
                    <h4 class="mb-4">Add A Merchant</h4>
                    <form action="<?php echo e(route('admin.merchants.add')); ?>" method="POST" enctype="multipart/form-data">
                        <?php echo e(csrf_field()); ?>

                        <div class="row mb-3">
                            <label for="name" class="col-sm-4 col-form-label">Name</label>
                            <div class="col-sm-5">
                                <input type="text" class="form-control" id="name" name="name" value="<?php echo e(old('name')); ?>">
                                <?php if($errors->has('name')): ?>
                                    <span class="help-block"><?php echo $errors->first('name'); ?></span>
                                <?php endif; ?>
                            </div>
                        </div>
                        <div class="row mb-3">
                            <label for="email" class="col-sm-4 col-form-label">Email</label>
                            <div class="col-sm-5">
                                <input type="email" class="form-control" id="email" name="email" value="<?php echo e(old('email')); ?>">
                                <?php if($errors->has('email')): ?>
                                    <span class="help-block"><?php echo $errors->first('email'); ?></span>
                                <?php endif; ?>
                            </div>
                        </div>
                        <div class="row mb-3">
                            <label for="telephone" class="col-sm-4 col-form-label">Telephone</label>
                            <div class="col-sm-5">
                                <input type="text" class="form-control" id="telephone" name="telephone" value="<?php echo e(old('telephone')); ?>">
                                <?php if($errors->has('telephone')): ?>
                                    <span class="help-block"><?php echo $errors->first('telephone'); ?></span>
                                <?php endif; ?>
                            </div>
                        </div>
                        <div class="row mb-3">
                            <label for="address" class="col-sm-4 col-form-label">Address</label>
                            <div class="col-sm-5">
                                <input type="text" class="form-control" id="address" name="address" value="<?php echo e(old('address')); ?>">
                                <?php if($errors->has('address')): ?>
                                    <span class="help-block"><?php echo $errors->first('address'); ?></span>
                                <?php endif; ?>
                            </div>
                        </div>
                        <div class="row mb-3">
                            <label for="payment_method" class="col-sm-4 col-form-label">Payment Methods</label>
                            <div class="col-sm-5">
                                <input type="checkbox" name="credit_card"> &nbsp;
                                <label for="telephone" class="col-sm-4 col-form-label">Credit Card</label> <br>
                                <input type="checkbox" name="paypal">&nbsp;
                                <label for="paypal" class="col-sm-4 col-form-label">Paypal</label> <br>
                                <input type="checkbox" name="user_credit">&nbsp;
                                <label for="user_credit" class="col-sm-4 col-form-label">User Credit</label>
                            </div>
                        </div>

                        <div class="row mb-3">
                            <label for="logo" class="col-sm-4 col-form-label">LOGO</label>
                            <div class="col-sm-5">
                                <img  src="" id="imgPreview"
                                alt="No Featured Image Added" style="width: 500px; height: 250px; ">
                            <input onchange="readURL(this)" id="uploadFile" accept="image/*"
                                name="logo" type="file">
                            </div>
                        </div>
                        <div class="row mb-3">
                            <label  class="col-sm-4 col-form-label"></label>
                            <button type="submit" class="btn  col-sm-5 btn-primary">Add</button>
                        </div>


                    </form>
                </div>
            </div>

        </div>
    </div>
    <!-- Form End -->
<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>
<script>
    function readURL(input) {

        if (input.files && input.files[0]) {
            var reader = new FileReader();

            reader.onload = function(e) {
                $('#imgPreview').attr('src', e.target.result);
            }

            reader.readAsDataURL(input.files[0]);
        }
    }
</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/vhosts/backpocket.ca/checkout.backpocket.ca/resources/views/admin/merchants/create.blade.php ENDPATH**/ ?>