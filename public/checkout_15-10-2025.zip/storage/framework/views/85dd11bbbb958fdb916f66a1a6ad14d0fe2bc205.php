

<?php $__env->startSection('content'); ?>
    <!-- Form Start -->
    <div class="container-fluid pt-4 px-4">
        <div class="row g-4">
            <div class="col-sm-12 col-md-12">
                <div class="bg-light rounded h-100 p-4">
                    <div class="pull-right" style="float: right;">
                        <a href="<?php echo e(route('admin.merchants.edit',  ['merchant' => $merchant])); ?>"><button type="button" class="btn btn-success">Edit</button></a>
                        <a href="<?php echo e(route('admin.merchants.index')); ?>"><button type="button" class="btn btn-primary">Merchants</button></a>
                    </div>
                    <table class="table ">
                        <tr>
                            <td>
                                Name
                            </td>
                            <td>
                                <?php echo e($merchant->name); ?>

                            </td>
                        </tr>
                        <tr>
                            <td>
                                Name
                            </td>
                            <td>
                                <?php echo e($merchant->email); ?>

                            </td>
                        </tr>
                        <tr>
                            <td>
                                Telephone
                            </td>
                            <td>
                                <?php echo e($merchant->telephone); ?>

                            </td>
                        </tr>
                        <tr>
                            <td>
                                Address
                            </td>
                            <td>
                                <?php echo e($merchant->address); ?>

                            </td>
                        </tr>
                        <tr>
                            <td>
                                Merchant Code
                            </td>
                            <td>
                                <?php echo e($merchant->merchant_code); ?>

                            </td>
                        </tr>
                        <tr>
                            <td>
                                Secret ID
                            </td>
                            <td>
                                <?php echo e($merchant->secret_id); ?>

                            </td>
                        </tr>
                        <tr>
                            <td>
                                Store Name
                            </td>
                            <td>
                                <?php echo e($merchant->store_name); ?>

                            </td>
                        </tr>
                    </table>
                </div>
            </div>

        </div>
    </div>
    <!-- Form End -->
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\payment-portal\resources\views/admin/merchants/show.blade.php ENDPATH**/ ?>