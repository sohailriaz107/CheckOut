

<?php $__env->startSection('content'); ?>
 
    <!-- Form Start -->
    <div class="container-fluid pt-4 px-4">
        <div class="row g-4">
            <div class="col-sm-12 col-md-12">
                <div class="bg-light rounded h-100 p-4">
                    <h6 class="mb-4">Add A Merchant</h6>
                    <form>
                        <div class="row mb-3">
                            <label for="name" class="col-sm-2 col-form-label">Name</label>
                            <div class="col-sm-10">
                                <input type="text" class="form-control" id="name">
                            </div>
                        </div>
                        <div class="row mb-3">
                            <label for="email" class="col-sm-2 col-form-label">Email</label>
                            <div class="col-sm-10">
                                <input type="email" class="form-control" id="email">
                            </div>
                        </div>
                        <div class="row mb-3">
                            <label for="telephone" class="col-sm-2 col-form-label">Telephone</label>
                            <div class="col-sm-10">
                                <input type="text" class="form-control" id="telephone" name="telephone">
                            </div>
                        </div>
                        <div class="row mb-3">
                            <label for="address" class="col-sm-2 col-form-label">Address</label>
                            <div class="col-sm-10">
                                <input type="text" class="form-control" id="address">
                            </div>
                        </div>
                        <div class="row mb-3">
                            <label for="merchant_code" class="col-sm-2 col-form-label">Merchant Code</label>
                            <div class="col-sm-10">
                                <input type="text" class="form-control" id="merchant_code">
                            </div>
                        </div>
                        <div class="row mb-3">
                            <label for="sercret_id" class="col-sm-2 col-form-label">Secret Id</label>
                            <div class="col-sm-10">
                                <input type="text" class="form-control" id="sercret_id">
                            </div>
                        </div>
                        <div class="row mb-3">
                            <label for="store_name" class="col-sm-2 col-form-label">Store Name</label>
                            <div class="col-sm-10">
                                <input type="text" class="form-control" id="store_name">
                            </div>
                        </div>
                       
                        <button type="submit" class="btn btn-primary">Sign in</button>
                    </form>
                </div>
            </div>
         
        </div>
    </div>
    <!-- Form End -->

<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\PaymentPortal\resources\views/admin/merchants/create.blade.php ENDPATH**/ ?>