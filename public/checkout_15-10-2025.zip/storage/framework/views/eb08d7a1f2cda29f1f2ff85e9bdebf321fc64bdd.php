<?php $__env->startSection('content'); ?>
    <!-- Form Start -->
    <div class="container-fluid pt-4 px-4">
        <div class="row g-4">
            <div class="col-sm-6 col-md-6">
                <div class="bg-light rounded h-100 p-4">
                    <table class="table ">
                        <tr>
                            <td>
                                <b>ID</b>
                            </td>
                            <td>
                                <?php echo e($transaction->transaction_id); ?>

                            </td>
                        </tr>
                        <tr>
                            <td>
                                <b>Invoice Number</b>
                            </td>
                            <td>
                                <?php echo e($transaction->invoice_no); ?>

                            </td>
                        </tr>
                        <tr>
                            <td>
                                <b>Referance Id</b>
                            </td>
                            <td>
                                <?php echo e($partial->transaction_id); ?>

                            </td>
                        </tr>
                        <tr>
                            <td>
                                <b>Merchant</b>
                            </td>
                            <td>
                                <?php echo e($transaction->merchant->name); ?>

                            </td>
                        </tr>
                        <tr>
                            <td>
                                <b>Order ID</b>
                            </td>
                            <td>
                                <?php echo e($transaction->order_id); ?>

                            </td>
                        </tr>
                        <tr>
                            <td>
                                <b>Payment Type</b>
                            </td>
                            <td>
                                <?php if($transaction->payment_type == 'credit_card'): ?>
                                Credit Card
                                <?php elseif($transaction->payment_type == 'paypal'): ?>
                                 Pay Pal
                                <?php endif; ?>
                            </td>
                        </tr>
                        <tr>
                            <td>
                                <b>Payment Date</b>
                            </td>
                            <td>
                                <?php echo e(date('m-d-Y', strtotime($transaction->payment_date))); ?>

                            </td>
                        </tr>
                        <tr>
                            <td>
                                <b>Amount</b>
                            </td>
                            <td>
                                CAD <?php echo e($transaction->amount); ?>

                            </td>
                        </tr>
                        <tr>
                            <td>
                                <b>Status</b>
                            </td>
                            <td>
                                <?php if($transaction->status == 'pending'): ?>
                                Pending
                                <?php elseif($transaction->status == 'completed'): ?>
                                Complete
                                <?php endif; ?>
                            </td>
                        </tr>
                    </table>
                </div>
            </div>
            <?php if($transaction->payment_type == 'credit_card' AND isset($payment_log->otherInfo)): ?>
            <div class=" bg-light  col-sm-6 col-md-6 p-2">
                <button type="submit" class="btn btn-success"  onclick="showHide()">See Payment Log</button>
                <div class="bg-light rounded  p-4 hidden" id="moreInfo" style="display:none;">
                    <?php
                        $payment_log=json_decode($payment_log->otherInfo);
                    ?>
                    <table class="table">
                        <tr>
                            <td><b>ID</b></td>
                            <td><?php echo e($payment_log->id); ?></td>
                        </tr>
                        <tr>
                            <td><b>Approved</b></td>
                            <td><?php echo e(($payment_log->approved)?'Yes':'No'); ?></td>
                        </tr>
                        <tr>
                            <td><b>Message</b></td>
                            <td><?php echo e($payment_log->message); ?></td>
                        </tr>
                        <tr>
                            <td><b>Created</b></td>
                            <td><?php echo e($payment_log->created); ?></td>
                        </tr>
                        <tr>
                            <td><b>Order Number</b></td>
                            <td><?php echo e($payment_log->order_number); ?></td>
                        </tr>
                        <tr>
                            <td><b>Risk Score</b></td>
                            <td><?php echo e($payment_log->risk_score); ?></td>
                        </tr>
                        <tr>
                            <td><b>Amount</b></td>
                            <td><?php echo e(number_format((float)$payment_log->amount, 2, '.', '')); ?></td>
                        </tr>
                    </table>
                </div>
                </div>
            </div>
            <?php endif; ?>
            <div class="pull-right" style="float: left;">
                <a href="<?php echo e(route('admin.transactions.index')); ?>"><button type="button" class="btn btn-primary">Go Back</button></a>
            </div>
    </div>
    <!-- Form End -->
<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>

<script>
    function showHide() {
        var table = document.getElementById("moreInfo");
            if (table.style.display === "none") {
                table.style.display = "block";
            } else {
                table.style.display = "none";
            }
    }
</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/vhosts/backpocket.ca/checkout.backpocket.ca/resources/views/admin/transactions/show.blade.php ENDPATH**/ ?>