<?php $__env->startSection('content'); ?>

    <!-- Form Start -->

    <div class="container-fluid pt-4 px-4">

        <div class="row g-4">

            <div class="col-sm-12 col-md-12">

                <div class="bg-light rounded h-100 p-4">

                    <div class="pull-right" style="float: right;">

                        <a href="<?php echo e(route('admin.transactions.index')); ?>"><button type="button" class="btn btn-primary">Transactions</button></a>

                    </div>

                    <table class="table ">

                        <tr>

                            <td>

                                ID

                            </td>

                            <td>

                                <?php echo e($transaction->id); ?>


                            </td>

                        </tr>

                        <tr>

                            <td>

                                Invoice Number

                            </td>

                            <td>

                                <?php echo e($transaction->invoice_no); ?>


                            </td>

                        </tr>

                        <tr>

                            <td>

                                Merchant

                            </td>

                            <td>

                                <?php echo e($transaction->merchant->name); ?>


                            </td>

                        </tr>

                        <tr>

                            <td>

                                Order ID

                            </td>

                            <td>

                                <?php echo e($transaction->order_id); ?>


                            </td>

                        </tr>

                        <tr>

                            <td>

                                Payment Type

                            </td>

                            <td>

                                <?php if($transaction->payment_type == 'credit_card'): ?>

                                Credit Card

                                <?php elseif($transaction->payment_type == 'paypal'): ?>

                                 Pay Pal

                                <?php endif; ?>

                            </td>
                        </tr>
                        <tr>
                            <td>
                                Payment Date
                            </td>
                            <td>
                                <?php echo e(date('m-d-Y', strtotime($transaction->payment_date))); ?>

                            </td>
                        </tr>
                        <tr>
                            <td>
                                Amount
                            </td>
                            <td>
                                CAD <?php echo e($transaction->amount); ?>

                            </td>
                        </tr>
                        <tr>
                            <td>
                                Status
                            </td>
                            <td>
                                <?php if($transaction->status == 'pending'): ?>
                                Pending
                                <?php elseif($transaction->status == 'complete'): ?>
                                Complete
                                <?php endif; ?>
                            </td>
                        </tr>
                    </table>
                </div>
            </div>
        </div>
    </div>
    <!-- Form End -->

<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp\www\checkout\resources\views/admin/transactions/show.blade.php ENDPATH**/ ?>